from django.apps import AppConfig


class StudentdatabankConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'StudentDataBank'
