from django.db import models

# Create your models here.

class Student(models.Model):
    roll_number = models.CharField(max_length=10,  primary_key=True)
    cgpa = models.FloatField()
    gender = models.BooleanField()
    semester = models.IntegerField(default=0)


class User(models.Model):
    name=models.CharField(max_length=15)
    email=models.CharField(primary_key=True,max_length=20)
    password=models.CharField(max_length=25)

class Task(models.Model):
    task_id = models.AutoField(primary_key=True)
    task_statement = models.CharField(max_length=50)
    user_email = models.ForeignKey(User, on_delete=models.CASCADE, to_field='email')

    def __str__(self):
        return f"Task: {self.task_statement} - User: {self.user.email}"

    