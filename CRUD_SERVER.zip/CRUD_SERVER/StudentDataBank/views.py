#from django.shortcuts import render

# Create your views here.
from django.shortcuts import get_object_or_404
from django.http import HttpResponse
from .models import Student,Task,User
from django.core import serializers

def index(request):
    return HttpResponse("Welcome to Mobile App Development with BITF20")

#USER
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

@csrf_exempt
def create_user(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            name = data.get('name')
            email = data.get('email')
            password = data.get('password')
            user =User.objects.create(name=name, email=email, password=password)
            return JsonResponse({"name": user.name,"email": user.email}, status=201)
        except json.decoder.JSONDecodeError as e:
            return JsonResponse({"error": "Invalid JSON format"}, status=400)
    return JsonResponse({"message": "Invalid request"}, status=400)

@csrf_exempt
def get_user_by_email(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            email = data.get('email')
            password = data.get('password')
            user = User.objects.get(email=email, password=password)
            return JsonResponse({"name": user.name}, status=201)
        except User.DoesNotExist:
            return JsonResponse({"name": ""}, status=400)
    return JsonResponse({"message": "Invalid request"}, status=400)

#LittlelEMON
@csrf_exempt
def SignIn(request,email,password):
    if request.method == 'GET':
        try:
            user = User.objects.get(email=email, password=password)
            if(user):
                
                return JsonResponse({"message": "Successfully Logged In"}, status=201)
        except User.DoesNotExist:
            return JsonResponse({"message": "Incorrect Credentials"}, status=400)
    return JsonResponse({"message": "Invalid request"}, status=400)
    
#lITTLElEMON
def allusers(request):
    users = User.objects.all()
    user_data = [{'email': user.email, 'password': user.password} for user in users]
    return JsonResponse(user_data, safe=False)

#TASK
def allTasks(request, email):
    if request.method == 'GET':
        tasks = Task.objects.filter(user_email__email=email)
        data = [{"task_statement": task.task_statement} for task in tasks]
        return JsonResponse(data, safe=False)
    return JsonResponse({"message": "Invalid request"}, status=400)


@csrf_exempt
def deleteTask(request, task_statement, user_email):
    if request.method == 'DELETE':
        try:
            user = User.objects.get(email=user_email)
            task = Task.objects.get(task_statement=task_statement, user_email=user)
            task.delete()
            return JsonResponse({"task_statement": "Task Deleted Successfully!"}, status=200)
        except Exception as e:
            return JsonResponse({"error": f"Error: {str(e)}"}, status=400)
    return JsonResponse({"message": "Invalid request method"}, status=400)

@csrf_exempt
def addTask(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            print(data)
            task_statement = data.get('task_statement')
            user_email = data.get('user_email')
            user = User.objects.get(email=user_email)
            task = Task.objects.create(task_statement=task_statement, user_email=user)
            return JsonResponse({"message":task.task_statement}, status=201)
        except Exception as e:
            return JsonResponse({"message": f"Error: {str(e)}"}, status=400)
    return JsonResponse({"message": "Invalid request"}, status=400)

@csrf_exempt
def updateTask(request, task_statement, user_email):
    if request.method == 'PUT':
        try:
            data = json.loads(request.body)
            updated_task_statement = data.get('task_statement')
            user = User.objects.get(email=user_email)
            task = Task.objects.get(task_statement=task_statement, user_email=user)
            task.task_statement = updated_task_statement
            task.save()
            return JsonResponse({"message": "Task updated successfully"}, status=200)
        except Exception as e:
            return JsonResponse({"message": f"Error: {str(e)}"}, status=400)
    return JsonResponse({"message": "Invalid request"}, status=400)

