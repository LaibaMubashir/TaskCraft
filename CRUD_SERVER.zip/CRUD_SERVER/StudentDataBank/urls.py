'''
Created on 20-Nov-2023

@author: mianm
'''

from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("allTasks/<str:email>/", views.allTasks, name="allTasks"),
    path("deleteTask/<str:task_statement>/<str:user_email>", views.deleteTask, name="deleteTask"),
    path("addTask/", views.addTask, name="addTask"),
    path("updateTask/<str:task_statement>/<str:user_email>", views.updateTask, name="updateTask"),
    path("SignUp/", views.create_user, name="create_user"),
    path("SignIn/", views.get_user_by_email, name="get_user_by_email"),

    path("signIn/<str:email>/<str:password>",views.SignIn,name="SignIn"),
    path("allusers/",views.allusers,name="allusers")


]